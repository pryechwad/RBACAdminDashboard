
import { RbacProvider } from './context/RbacProvider';  // Import the provider from the new file
import Users from '../pages/Users';
import Roles from '../pages/Roles';

const App = () => {
  return (
    <RbacProvider>
      <Users />
      <Roles />
    </RbacProvider>
  );
};

export default App;
