import { useContext } from 'react';
import { RbacContext } from '../context/RbacContext';

// Custom hook to access the context
export const useRbac = () => useContext(RbacContext);
