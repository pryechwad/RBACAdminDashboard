import { createContext } from 'react';

// Create the context
export const RbacContext = createContext();
