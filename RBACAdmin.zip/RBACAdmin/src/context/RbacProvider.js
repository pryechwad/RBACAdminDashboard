import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { RbacContext } from './RbacContext';
import { getUsers, getRoles } from '@api/mockApi';  // Ensure this path is correct

// Provider component that wraps the app and provides the context
export const RbacProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const usersData = await getUsers();
        const rolesData = await getRoles();
        setUsers(usersData);
        setRoles(rolesData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <RbacContext.Provider value={{ users, setUsers, roles, setRoles }}>
      {children}
    </RbacContext.Provider>
  );
};

RbacProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
