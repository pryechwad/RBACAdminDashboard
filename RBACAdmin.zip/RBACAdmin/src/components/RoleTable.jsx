import PropTypes from "prop-types";

const RoleTable = ({ roles, onEdit, onDelete }) => (
  <div className="overflow-x-auto">
    <table className="table-auto w-full border-collapse border border-gray-300">
      <thead>
        <tr className="bg-gray-100">
          <th className="border border-gray-300 px-4 py-2">Role Name</th>
          <th className="border border-gray-300 px-4 py-2">Permissions</th>
          <th className="border border-gray-300 px-4 py-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        {roles.length > 0 ? (
          roles.map((role) => (
            <tr key={role.id} className="even:bg-gray-50">
              <td className="border border-gray-300 px-4 py-2">{role.name}</td>
              <td className="border border-gray-300 px-4 py-2">
                {role.permissions.join(", ")}
              </td>
              <td className="border border-gray-300 px-4 py-2">
                <button
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:ring-2 focus:ring-blue-300 mr-2"
                  onClick={() => onEdit(role)}
                  aria-label={`Edit role ${role.name}`}
                >
                  Edit
                </button>
                <button
                  className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 focus:ring-2 focus:ring-red-300"
                  onClick={() => onDelete(role.id)}
                  aria-label={`Delete role ${role.name}`}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td
              colSpan="3"
              className="border border-gray-300 px-4 py-2 text-center text-gray-500"
            >
              No roles available.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
);

// Prop validation
RoleTable.propTypes = {
  roles: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      permissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    })
  ).isRequired,
  onEdit: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
};

export default RoleTable;
