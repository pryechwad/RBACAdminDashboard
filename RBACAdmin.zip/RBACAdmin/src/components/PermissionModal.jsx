import PropTypes from "prop-types"; // For prop validation

const PermissionModal = ({ isOpen, role, permissions, onSave, onClose }) => {
  if (!isOpen) return null;

  const handlePermissionChange = (permission, isChecked) => {
    const updatedPermissions = isChecked
      ? [...role.permissions, permission]
      : role.permissions.filter((perm) => perm !== permission);

    onSave({ ...role, permissions: updatedPermissions });
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">Manage Permissions for {role.name}</h2>
        <ul>
          {permissions.map((permission) => (
            <li key={permission} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={permission}
                checked={role.permissions.includes(permission)}
                onChange={(e) => handlePermissionChange(permission, e.target.checked)}
                className="mr-2"
              />
              <label htmlFor={permission}>{permission}</label>
            </li>
          ))}
        </ul>
        <div className="flex justify-end mt-4">
          <button
            onClick={onClose}
            className="bg-gray-300 hover:bg-gray-400 text-black font-bold py-2 px-4 rounded mr-2"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(role)}
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

// Prop validation
PermissionModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  role: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    permissions: PropTypes.arrayOf(PropTypes.string).isRequired,
  }).isRequired,
  permissions: PropTypes.arrayOf(PropTypes.string).isRequired,
  onSave: PropTypes.func.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default PermissionModal;
