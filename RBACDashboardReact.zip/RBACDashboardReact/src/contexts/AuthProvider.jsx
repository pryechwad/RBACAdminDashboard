

import  { useState } from 'react';
import PropTypes from 'prop-types';  // Make sure prop-types is imported
import { AuthContext } from './AuthContext'; // Import the context

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // Local state for the logged-in user

  // Login method to set the user
  const login = (userData) => {
    setUser(userData);
  };

  // Logout method to clear the user
  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Prop validation for 'children'
AuthProvider.propTypes = {
  children: PropTypes.node.isRequired, // Validates children as React nodes
};

export default AuthProvider;
