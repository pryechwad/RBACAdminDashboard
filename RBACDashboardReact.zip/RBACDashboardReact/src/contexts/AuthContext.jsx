// src/contexts/AuthContext.js

import { createContext } from 'react';

// Create AuthContext for managing user state
export const AuthContext = createContext();
