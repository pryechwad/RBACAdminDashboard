import PropTypes from 'prop-types';

const RoleTable = ({ roles, onEdit, onDelete }) => {
  return (
    <table className="min-w-full mt-6 border-collapse">
      <thead>
        <tr>
          <th className="border px-4 py-2">Role Name</th>
          <th className="border px-4 py-2">Permissions</th>
          <th className="border px-4 py-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        {roles.map((role) => (
          <tr key={role.id}>
            <td className="border px-4 py-2">{role.name}</td>
            <td className="border px-4 py-2">{role.permissions.join(', ')}</td>
            <td className="border px-4 py-2">
              <button
                onClick={() => onEdit(role.id)}
                className="bg-blue-500 text-white px-4 py-2 rounded"
              >
                Edit
              </button>
              <button
                onClick={() => onDelete(role.id)}
                className="bg-red-500 text-white px-4 py-2 rounded ml-2"
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

// Prop types validation
RoleTable.propTypes = {
  roles: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      permissions: PropTypes.arrayOf(PropTypes.string).isRequired,
    })
  ).isRequired,
  onEdit: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
};

export default RoleTable;
