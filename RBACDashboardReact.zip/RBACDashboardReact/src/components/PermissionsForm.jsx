import PropTypes from 'prop-types'; // Import PropTypes
import  { useState } from 'react'; 
const PermissionsForm = ({ permissions, availablePermissions, onSave }) => {
  const [selectedPermissions, setSelectedPermissions] = useState(permissions);

  const togglePermission = (permission) => {
    setSelectedPermissions((prev) =>
      prev.includes(permission)
        ? prev.filter((perm) => perm !== permission)
        : [...prev, permission]
    );
  };

  const handleSave = () => {
    onSave(selectedPermissions);
  };

  return (
    <div className="p-4 border rounded">
      <h3 className="mb-4">Edit Permissions</h3>
      <div className="space-y-2">
        {availablePermissions.map((permission) => (
          <div key={permission} className="flex items-center">
            <input
              type="checkbox"
              checked={selectedPermissions.includes(permission)}
              onChange={() => togglePermission(permission)}
              className="mr-2"
            />
            <span>{permission}</span>
          </div>
        ))}
      </div>
      <button
        onClick={handleSave}
        className="bg-green-500 text-white px-4 py-2 rounded mt-4"
      >
        Save Permissions
      </button>
    </div>
  );
};

// Add prop validation for 'permissions', 'availablePermissions', and 'onSave'
PermissionsForm.propTypes = {
  permissions: PropTypes.arrayOf(PropTypes.string).isRequired, // Array of strings
  availablePermissions: PropTypes.arrayOf(PropTypes.string).isRequired, // Array of strings
  onSave: PropTypes.func.isRequired, // Function for saving permissions
};

export default PermissionsForm;
