import { useEffect, useState } from "react";
import { fetchUsers, fetchRoles, createUser, updateUser, deleteUser } from "../utils/api";
import UserTable from "../components/UserTable";
import RoleTable from "../components/RoleTable";

const DashboardPage = () => {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);

  useEffect(() => {
    // Fetch users and roles on initial load
    fetchUsers().then(setUsers);
    fetchRoles().then(setRoles);
  }, []);

  // Add a new user (mocked)
  const handleAddUser = () => {
    const newUser = { id: users.length + 1, name: 'New User', role: 'User', status: 'Active' };
    createUser(newUser).then((user) => setUsers((prev) => [...prev, user]));
  };

  // Delete user (mocked)
  const handleDeleteUser = (userId) => {
    deleteUser(userId).then(() => {
      setUsers((prevUsers) => prevUsers.filter((user) => user.id !== userId));
    });
  };

  // Update user role (mocked)
  const handleUpdateUserRole = (userId, newRole) => {
    updateUser(userId, { role: newRole }).then((updatedUser) => {
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === userId ? { ...user, role: updatedUser.role } : user
        )
      );
    });
  };

  return (
    <div>
      <h1 className="text-2xl mb-4">Dashboard</h1>
      <button onClick={handleAddUser} className="bg-green-500 text-white px-4 py-2 rounded">
        Add User
      </button>
      <div className="mt-6">
        <h2 className="text-xl mb-4">Users</h2>
        <UserTable
          users={users}
          onDelete={handleDeleteUser}
          onUpdateRole={handleUpdateUserRole}
        />
      </div>
      <div className="mt-6">
        <h2 className="text-xl mb-4">Roles</h2>
        <RoleTable roles={roles} />
      </div>
    </div>
  );
};

export default DashboardPage;
