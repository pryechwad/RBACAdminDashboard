const users = [
    { id: 1, name: 'John Doe', role: 'Admin', status: 'Active' },
    { id: 2, name: 'Jane Smith', role: 'User', status: 'Inactive' },
  ];
  
  const roles = [
    { id: 1, name: 'Admin', permissions: ['Read', 'Write', 'Delete'] },
    { id: 2, name: 'User', permissions: ['Read'] },
  ];
  
  export const fetchUsers = () => Promise.resolve(users);
  export const fetchRoles = () => Promise.resolve(roles);
  export const createUser = (user) => {
    users.push(user);
    return Promise.resolve(user);
  };
  export const updateUser = (userId, updatedUser) => {
    const index = users.findIndex(user => user.id === userId);
    users[index] = { ...users[index], ...updatedUser };
    return Promise.resolve(updatedUser);
  };
  export const deleteUser = (userId) => {
    const index = users.findIndex(user => user.id === userId);
    users.splice(index, 1);
    return Promise.resolve();
  };
  export const createRole = (role) => {
    roles.push(role);
    return Promise.resolve(role);
  };
  export const updateRole = (roleId, updatedRole) => {
    const index = roles.findIndex(role => role.id === roleId);
    roles[index] = { ...roles[index], ...updatedRole };
    return Promise.resolve(updatedRole);
  };
  export const deleteRole = (roleId) => {
    const index = roles.findIndex(role => role.id === roleId);
    roles.splice(index, 1);
    return Promise.resolve();
  };
  