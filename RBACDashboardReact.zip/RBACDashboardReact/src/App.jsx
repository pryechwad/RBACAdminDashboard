
import AuthProvider from "./contexts/AuthProvider";

const App = () => {
  return (
    <AuthProvider>
      {/* Render other components here */}
      {/* <SomeComponent /> */}
    </AuthProvider>
  );
};

export default App;
